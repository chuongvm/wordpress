<?php

if (!defined('ABSPATH')) {
	exit;
}

if (!class_exists('OCC_Library', false)) {

	define('OCC_METAL_PRICE_POST_ID', 100); // Post Id to save post meta of metal prices
	define('OCC_METAL_PRICE_KEY_POST_META', 'occ_metal_prices'); // Meta key to save post meta of metal prices

	/**
	 * Class OCC_Library.
	 *
	 */
	class OCC_Library
	{
		// Method to get price from string
		public static function getPriceFromString(string $str)
		{
			$price = null;

			preg_match_all('/[0-9.,]+/', $str, $matches);

			if (!empty($matches[0])) {
				$price = end($matches[0]);
				$price = str_replace('.', '', $price);
				$price = str_replace(',', '.', $price);
				$price = floatval(trim($price));
			}

			return $price;
		}


		// Method to get metal from string
		public static function getMetalFromString(string $str)
		{
			$metal = null;
			$str = trim($str);
			if ($str) {
				$str = explode(' ', $str);
				$metalFrench = strtolower($str[0]);
				switch ($metalFrench) {
					case 'or':
						$metal = 'Gold';
						break;
					case 'argent':
						$metal = 'Silver';
						break;
					case 'platine':
						$metal = 'Platinum';
						break;
					case 'palladium':
						$metal = 'Palladium';
						break;
				}
			}

			return $metal;
		}


		// Method to get unit from string
		public static function getUnitFromString(string $str)
		{
			$unit = null;
			$str = trim($str);
			if ($str) {
				$str = explode(' ', $str);
				$un = strtolower(end($str));
				if (in_array($un, ['g', 'kg', 'oz'])) {
					$unit = $un;
				}
			}

			return $unit;
		}


		// Method to save metal prices to the postmeta of Wordpress
		// Return value: 
		// -1: get price fail (something wrong from RSS)
		// 0: Get price successfully but nothing change with old price
		// 1: Get price successfully and there is a change with old price
		public static function updateMetalPricesFromRss()
		{
			$rssUrl = 'https://www.cookson-clal.com/mp/rss_mpfr_cdl.jsp';
			$rss = Feed::loadRss($rssUrl);

			$newPrices = OCC_Library::getMetalPricesFromRss($rss);
			if ($newPrices) {
				if (metadata_exists('post', OCC_METAL_PRICE_POST_ID, OCC_METAL_PRICE_KEY_POST_META)) {
					$oldPrices = get_post_meta(OCC_METAL_PRICE_POST_ID, OCC_METAL_PRICE_KEY_POST_META, true);

					$different = array_diff($newPrices, $oldPrices);
					if (empty($different)) {
						return 0;
					}

					if (update_post_meta(OCC_METAL_PRICE_POST_ID, OCC_METAL_PRICE_KEY_POST_META, $newPrices)) {
						return 1;
					}
				} else {
					if (add_post_meta(OCC_METAL_PRICE_POST_ID, OCC_METAL_PRICE_KEY_POST_META, $newPrices, true)) {
						return 1;
					}
				}
			}

			return -1;	// get price fail
		}


		// Method to get 4 price of metals from RSS content
		public static function getMetalPricesFromRss($rss)
		{
			$prices = null;

			$items = [];
			foreach ($rss->item as $item) {
				$items[] = $item;
			}

			if (!empty($items)) {
				$prices = [];
				$totalItem = count($items);

				for ($i = 1; $i < ($totalItem - 1); $i++) {   // ignore the first and the last item
					$item = $items[$i];

					$price = OCC_Library::getPriceFromString($item->title);
					$metal = OCC_Library::getMetalFromString($item->title);
					if ($price && $metal) {
						$prices[$metal] = $price;
					}
				}
			}

			return $prices;
		}


		// Method to calculate price from metal, weight and unit
		public static function calculatePrice(string $metal, float $weight, string $unit)
		{
			$price = null;

			if ($metal && $weight && $unit) {

				$prices = get_post_meta(OCC_METAL_PRICE_POST_ID, OCC_METAL_PRICE_KEY_POST_META, true);

				if (isset($prices[$metal])) {
					$priceKg = $prices[$metal];
					if ($unit == 'g') {
						$priceOneUnit = $priceKg / 1000;
					} else if ($unit == 'oz') {
						$priceOneUnit = $priceKg / 35.274;
					} else {
						$priceOneUnit = $priceKg;
					}
					$price = $priceOneUnit * $weight;
				}
			}

			return $price;
		}


		// Method to create all attribute and term of OCC product
		public static function createProductAttributes()
		{
			// Create Product Type attribute and terms
			OCC_Library::createAttribute('Type', 'occ-product-type');
			OCC_Library::createTerm('Bar', 'occ-product-type-bar', 'occ-product-type', 10);
			OCC_Library::createTerm('Ingot', 'occ-product-type-ingot', 'occ-product-type', 20);
			OCC_Library::createTerm('Piece', 'occ-product-type-piece', 'occ-product-type', 30);

			// Create Product Metal attribute and terms
			OCC_Library::createAttribute('Metal', 'occ-product-metal');
			OCC_Library::createTerm('Gold', 'occ-product-metal-gold', 'occ-product-metal', 10);
			OCC_Library::createTerm('Silver', 'occ-product-metal-silver', 'occ-product-metal', 20);
			OCC_Library::createTerm('Platinum', 'occ-product-metal-platinum', 'occ-product-metal', 30);
			OCC_Library::createTerm('Palladium', 'occ-product-metal-palladium', 'occ-product-metal', 40);

			// Create Unit attribute and terms
			OCC_Library::createAttribute('Unit', 'occ-product-unit');
			OCC_Library::createTerm('g', 'occ-product-unit-g', 'occ-product-unit', 10);
			OCC_Library::createTerm('kg', 'occ-product-unit-kg', 'occ-product-unit', 20);
			OCC_Library::createTerm('oz', 'occ-product-unit-oz', 'occ-product-unit', 30);
		}


		// Method to add some fake images to generate products
		public static function addFakeImages()
		{
			$imgs = ['img01.jpg', 'img02.jpg', 'img03.jpg', 'img04.jpg', 'img05.jpg', 'img06.jpg', 'img07.jpg', 'img08.jpg', 'img09.jpg', 'img10.jpg'];
			foreach ($imgs as $img) {
				$imgPath = get_site_url() . '/wp-content/plugins/officience-product-rss/assets/images/' . $img;
				OCC_Library::rudr_upload_file_by_url($imgPath);
			}
		}


		// Method to update price of all demo products
		public static function updateProductsPrice()
		{
			$query = new WP_Query(
				array(
					'posts_per_page'      => -1,
					'fields'              => 'ids',
					'post_type'           => 'product'
				)
			);

			$products = $query->get_posts();
			foreach ($products as $productId) {
				$product = wc_get_product($productId);

				$metal = $product->attributes['type']['options'][0];
				$weight = $product->attributes['weight']['options'][0];
				$unit = $product->attributes['unit']['options'][0];

				$price = OCC_Library::calculatePrice($metal, $weight, $unit);

				$product->set_regular_price($price);
				$product->save();
			}

			return true;
		}


		// Method to generate 100 product for demo
		public static function generateProducts()
		{
			for ($i = 0; $i < 100; $i++) {
				OCC_Library::generateProduct();
			}
		}


		// Method to generate 1 product
		public static function generateProduct()
		{
			// Create attributes
			$attrs = [];

			// Random type
			$types = ['Bar', 'Ingot', 'Piece'];
			$randKey = array_rand($types);
			$type = $types[$randKey];
			$attrName = 'Type';
			$attrValue = $type;
			$attr = new WC_Product_Attribute();
			$attr->set_name($attrName);
			$attr->set_options([$attrValue]);
			$attr->set_visible(1);
			$attrs[$attrName] = $attr;

			// Random weight
			$attrName = 'Weight';
			$weight = rand(1, 10);
			$attrValue = $weight;
			$attr = new WC_Product_Attribute();
			$attr->set_name($attrName);
			$attr->set_options([$attrValue]);
			$attr->set_visible(1);
			$attrs[$attrName] = $attr;

			// Random unit
			$units = ['g', 'kg', 'oz'];
			$randKey = array_rand($units);
			$unit = $units[$randKey];
			$attrName = 'Unit';
			$attrValue = $unit;
			$attr = new WC_Product_Attribute();
			$attr->set_name($attrName);
			$attr->set_options([$attrValue]);
			$attr->set_visible(1);
			$attrs[$attrName] = $attr;

			// Random purity
			$purites = [999.9, 990, 916, 950, 960, 999.1, 980, 985, 900, 975];
			$randKey = array_rand($purites);
			$purity = $purites[$randKey];
			$attrName = 'Purity';
			$attrValue = $purity;
			$attr = new WC_Product_Attribute();
			$attr->set_name($attrName);
			$attr->set_options([$attrValue]);
			$attr->set_visible(1);
			$attrs[$attrName] = $attr;

			// Random metal
			$metals = ['Gold', 'Silver', 'Platinum', 'Palladium'];
			$randKey = array_rand($metals);
			$metal = $metals[$randKey];
			$attrName = 'Metal';
			$attrValue = $metal;
			$attr = new WC_Product_Attribute();
			$attr->set_name($attrName);
			$attr->set_options([$attrValue]);
			$attr->set_visible(1);
			$attrs[$attrName] = $attr;

			$product = new WC_Product_Simple();

			// process name
			$productName = $weight . $unit . ' of ' . $metal;
			$product->set_name($productName);
			$product->set_slug(sanitize_title($productName));

			// process image
			$image = get_posts(
				array(
					'orderby'       => 'rand', //random order
					'numberposts' => 1, // numberposts, not posts_per_page
					'post_type'      => 'attachment',
					'post_mime_type' => 'image',
					'post_status'    => 'inherit'
				)
			);
			$product->set_image_id($image[0]->ID);

			// process price
			$price = OCC_Library::calculatePrice($metal, $weight, $unit);
			$product->set_regular_price($price);

			$product->set_attributes($attrs);

			if ($product->save()) {
				return true;
			}
			return false;
		}


		/**
		 * Upload image from URL programmatically
		 *
		 * @author Misha Rudrastyh
		 * @link https://rudrastyh.com/wordpress/how-to-add-images-to-media-library-from-uploaded-files-programmatically.html#upload-image-from-url
		 */
		public static function rudr_upload_file_by_url($image_url)
		{

			// it allows us to use download_url() and wp_handle_sideload() functions
			require_once(ABSPATH . 'wp-admin/includes/file.php');

			// download to temp dir
			$temp_file = download_url($image_url);

			if (is_wp_error($temp_file)) {
				return false;
			}

			// move the temp file into the uploads directory
			$file = array(
				'name'     => basename($image_url),
				'type'     => mime_content_type($temp_file),
				'tmp_name' => $temp_file,
				'size'     => filesize($temp_file),
			);
			$sideload = wp_handle_sideload(
				$file,
				array(
					'test_form'   => false // no needs to check 'action' parameter
				)
			);

			if (!empty($sideload['error'])) {
				// you may return error message if you want
				return false;
			}

			// it is time to add our uploaded image into WordPress media library
			$attachment_id = wp_insert_attachment(
				array(
					'guid'           => $sideload['url'],
					'post_mime_type' => $sideload['type'],
					'post_title'     => basename($sideload['file']),
					'post_content'   => '',
					'post_status'    => 'inherit',
				),
				$sideload['file']
			);

			if (is_wp_error($attachment_id) || !$attachment_id) {
				return false;
			}

			// update medatata, regenerate image sizes
			require_once(ABSPATH . 'wp-admin/includes/image.php');

			wp_update_attachment_metadata(
				$attachment_id,
				wp_generate_attachment_metadata($attachment_id, $sideload['file'])
			);

			return $attachment_id;
		}


		// Method to create attributes of WooCommerce products
		public static function createAttribute(string $attributeName, string $attributeSlug): ?\stdClass
		{
			delete_transient('wc_attribute_taxonomies');
			\WC_Cache_Helper::incr_cache_prefix('woocommerce-attributes');

			$attributeLabels = wp_list_pluck(wc_get_attribute_taxonomies(), 'attribute_label', 'attribute_name');
			$attributeWCName = array_search($attributeSlug, $attributeLabels, TRUE);

			if (!$attributeWCName) {
				$attributeWCName = wc_sanitize_taxonomy_name($attributeSlug);
			}

			$attributeId = wc_attribute_taxonomy_id_by_name($attributeWCName);
			if (!$attributeId) {
				$taxonomyName = wc_attribute_taxonomy_name($attributeWCName);
				unregister_taxonomy($taxonomyName);
				$attributeId = wc_create_attribute(array(
					'name' => $attributeName,
					'slug' => $attributeSlug,
					'type' => 'select',
					'order_by' => 'menu_order',
					'has_archives' => 0,
				));

				register_taxonomy($taxonomyName, apply_filters('woocommerce_taxonomy_objects_' . $taxonomyName, array(
					'product'
				)), apply_filters('woocommerce_taxonomy_args_' . $taxonomyName, array(
					'labels' => array(
						'name' => $attributeSlug,
					),
					'hierarchical' => FALSE,
					'show_ui' => FALSE,
					'query_var' => TRUE,
					'rewrite' => FALSE,
				)));
			}

			return wc_get_attribute($attributeId);
		}


		// Method to create term of attribute of WooCommerce products
		public static function createTerm(string $termName, string $termSlug, string $taxonomy, int $order = 0): ?\WP_Term
		{
			$taxonomy = wc_attribute_taxonomy_name($taxonomy);

			if (!$term = get_term_by('slug', $termSlug, $taxonomy)) {
				$term = wp_insert_term($termName, $taxonomy, array(
					'slug' => $termSlug,
				));
				$term = get_term_by('id', $term['term_id'], $taxonomy);
				if ($term) {
					update_term_meta($term->term_id, 'order', $order);
				}
			}

			return $term;
		}
	}
}
