<?php
/*
Plugin Name:  Officience Product RSS (test)
Plugin URI:   https://officience.com/
Description:  This plugin was created for testing purposes: Create products and update prices from RSS.
Version:      1.0
Author:       Chuong Vu
Author URI:   https://www.linkedin.com/in/chuongvm/
*/



define('OCC_TIME_INTERVAL', 600); // Number of seconds per price update run (10 minutes)
define('OCC_EMAIL_RECEIVE_NOTIFICATION', 'chuong.vm@gmail.com'); // Email for receive notification when update price from RSS is fail

include_once WP_PLUGIN_DIR . '/officience-product-rss/includes/libraries/class-occ-library.php';
include_once WP_PLUGIN_DIR . '/officience-product-rss/includes/libraries/rss-php-master/src/Feed.php';

// This function runs when the plugin is activated
function occ_activate()
{
    try {
        OCC_Library::updateMetalPricesFromRss();
        OCC_Library::addFakeImages();
        OCC_Library::createProductAttributes();
        OCC_Library::generateProducts();
        wp_schedule_event(time(), 'occ_time_interval', 'occ_time_interval_event');
    } catch (Exception $e) {
        echo 'Caught exception: ',  $e->getMessage(), "\n";
    }
}
register_activation_hook(__FILE__, 'occ_activate');

// This function runs when the plugin is deactivated
function occ_deactivate()
{
    try {
        wp_clear_scheduled_hook('occ_time_interval_event');
    } catch (Exception $e) {
        echo 'Caught exception: ',  $e->getMessage(), "\n";
    }
}
register_deactivation_hook(__FILE__, 'occ_deactivate');




// Function create cron schedule 10 minute
function occ_add_cron_schedules($schedules)
{
    $schedules['occ_time_interval'] = array(
        'interval' => OCC_TIME_INTERVAL,
        'display' => __('10 minutes')
    );
    return $schedules;
}
add_filter('cron_schedules', 'occ_add_cron_schedules');
add_action('occ_time_interval_event',  'occ_update_price');




// Function update product price from RSS
function occ_update_price()
{
    try {
        $update = OCC_Library::updateMetalPricesFromRss();

        if ($update == 1) {  // Only update product prices when metal prices change
            OCC_Library::updateProductsPrice();
        }

        if ($update == -1) {
            occ_send_notification();
        }
    } catch (Exception $e) {
        echo 'Caught exception: ',  $e->getMessage(), "\n";
        occ_send_notification();
    }
}

// Function send email
function occ_send_notification()
{
    $to = OCC_EMAIL_RECEIVE_NOTIFICATION;
    $subject = 'Updating price from RSS failed !!!';
    $message = 'Update metal prices failed at ' . date('Y-m-d H:i:s') . '. Please check the system again. Thank you. ';
    $headers = '';
    $attachments = '';
    wp_mail($to, $subject, $message, $headers, $attachments);
}

// function occ_test()
// {
// }
// add_action('init',  'occ_test');
